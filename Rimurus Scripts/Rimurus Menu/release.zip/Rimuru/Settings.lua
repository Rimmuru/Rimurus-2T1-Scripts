return {
	["language"] = [=[eng.lua]=],
	["y"] = 0.44652777777,
	["hotkey_notifications"] = {
		["action"] = false,
		["toggle"] = true,
	},
	["x"] = 0.5,
	["player_submenu_sort"] = 0,
	["selector_speed"] = 1,
	["side_window"] = {
		["padding"] = 0.01,
		["offset"] = {
			["x"] = 0.0,
			["y"] = 0,
		},
		["on"] = true,
		["spacing"] = 0.0547222,
		["width"] = 0.3,
	},
	["states"] = {
		["ceo"] = false,
		["typing"] = true,
		["paused"] = false,
	},
	["controls"] = {
		["left"] = [=[LEFTARROW]=],
		["right"] = [=[RIGHTARROW]=],
		["specialKey"] = [=[LCONTROL]=],
		["down"] = [=[DOWNARROW]=],
		["back"] = [=[BACKSPACE]=],
		["up"] = [=[UPARROW]=],
		["select"] = [=[ENTER]=],
		["open"] = [=[F5]=],
		["setHotkey"] = [=[F11]=],
	},
}