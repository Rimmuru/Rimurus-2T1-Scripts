return {
	["selector_speed"] = 1,
	["controls"] = {
		["up"] = [[UPARROW]],
		["right"] = [[RIGHTARROW]],
		["down"] = [[DOWNARROW]],
		["setHotkey"] = [[F11]],
		["specialKey"] = [[LCONTROL]],
		["left"] = [[LEFTARROW]],
		["select"] = [[ENTER]],
		["back"] = [[BACKSPACE]],
		["open"] = [[F5]],
	},
	["language"] = [[eng.lua]],
	["hotkey_notifications"] = {
		["action"] = false,
		["toggle"] = true,
	},
	["y"] = 0.44652777777,
	["x"] = 0.5,
	["side_window"] = {
		["offset"] = {
			["x"] = 0.0,
			["y"] = 0,
		},
		["padding"] = 0.01,
		["on"] = true,
		["width"] = 0.3,
		["spacing"] = 0.0547222,
	},
	["player_submenu_sort"] = 0,
	["states"] = {
		["paused"] = false,
		["ceo"] = false,
		["typing"] = false,
	},
}