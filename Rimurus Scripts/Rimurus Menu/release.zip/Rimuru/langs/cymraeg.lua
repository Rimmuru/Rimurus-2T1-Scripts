return {
    ["lang"] = "cymru",
    ["welcome"] = "Croeso i",
    ["player"] = [[Cymeriad]],
    ["weapon"] = "Araf",
    ["vehicle"] = "Cerbyd",
    ["online"] = "Ar-Lein",
    ["misc"] = "Amrywiol",
    ["spawner"] = "Grawn",
    ["world"] = "Byd"
}