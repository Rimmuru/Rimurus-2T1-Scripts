return {
    ["Welcome"] = "Welcome",
    ["player"] = "Player",
    ["weapon"] = "Weapon",
    ["vehicle"] = "Vehicle",
    ["online"] = "Online",
    ["misc"] = "Misc",
    ["spawner"] = "Spawner",
    ["world"] = "World",
}