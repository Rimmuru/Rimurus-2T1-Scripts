return {
	["action"] = false,
	["toggle"] = true,
}