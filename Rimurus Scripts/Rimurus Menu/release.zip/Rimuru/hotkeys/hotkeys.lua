return {
	["NOMOD|F9"] = {
		["Settings.Save_Settings"] = true,
	},
}