return {
	["red"] = 256,
	["green"] = 255,
	["blue"] = 140,
}