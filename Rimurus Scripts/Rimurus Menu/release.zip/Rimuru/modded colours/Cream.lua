return {
	["red"] = 255,
	["green"] = 248,
	["blue"] = 210,
}