return {
	["red"] = 0,
	["green"] = 150,
	["blue"] = 45,
}