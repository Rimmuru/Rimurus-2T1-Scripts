return {
	["red"] = 255,
	["green"] = 182,
	["blue"] = 193,
}