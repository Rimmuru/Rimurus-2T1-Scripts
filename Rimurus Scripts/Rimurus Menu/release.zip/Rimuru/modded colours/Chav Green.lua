return {
	["red"] = 179,
	["green"] = 255,
	["blue"] = 94,
}