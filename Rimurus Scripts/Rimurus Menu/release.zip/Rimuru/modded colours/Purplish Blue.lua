return {
	["red"] = 50,
	["green"] = 0,
	["blue"] = 255,
}