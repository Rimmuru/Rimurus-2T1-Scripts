return {
	["red"] = 211,
	["green"] = 228,
	["blue"] = 205,
}