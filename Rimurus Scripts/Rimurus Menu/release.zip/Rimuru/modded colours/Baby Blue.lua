return {
	["red"] = 202,
	["green"] = 243,
	["blue"] = 238,
}