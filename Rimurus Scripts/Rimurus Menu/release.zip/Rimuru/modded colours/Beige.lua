return {
	["red"] = 242,
	["green"] = 221,
	["blue"] = 193,
}