return {
	["red"] = 199,
	["green"] = 249,
	["blue"] = 251,
}