return {
	["red"] = 255,
	["green"] = 255,
	["blue"] = 49,
}